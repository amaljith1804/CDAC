from tkinter import *
from tkinter import filedialog, messagebox #import  classes
from PIL import ImageTk, Image #impot ImageTk module to view image
root = Tk()
root.title('Image Viewer')
root.file1=Label(root)
myLabel=Label(root)
myLabel.grid(row=1, column=1, columnspan=3)  #grid the label
# defining function
def load(m): #loading the image file
	img = Image.open(root.file1[m])
	sizing(img) #sizing function to resize the file
def sizing(img):
	h = img.size[1] #initializing the height and width
	w = img.size[0]
	if img.size[1]>700:# resize using filter image.ANTIALIAS		
		img = img.resize((int(700*w/h),700), Image.ANTIALIAS) #using ANTIALIAS filter to smoothen the edges
		w = img.size[0]
		h = img.size[1]	
	if  img.size[0]>1920: #resize the width
		img = img.resize((1600,int(1600*h/w)), Image.ANTIALIAS)
	List1.append(ImageTk.PhotoImage(img)) #appending it on an empty list List1
def openfile():
	if root.file1:
		backup = root.file1
	del root.file1
	root.file1 = filedialog.askopenfilenames(initialdir="", title="Select file", filetypes=(("jpg file",".jpg"),("png file",".png")))
	if not root.file1:
		exitComfirm = messagebox.askyesno("Do you want to exit?")
		if exitComfirm == 1:
			quit()
		else:
			root.file1 = backup
	else:
		global List1
		List1=[]
		load(0)
		imageprint(0)
		button1()
#for displaing image on screen
def imageprint(m):
	global myLabel
	myLabel.config(image=List1[m])
def button1():
	button_open = Button(root, text="OPEN", bg='#d87c7c', command=openfile)

openfile() #run the open file function
root.mainloop()