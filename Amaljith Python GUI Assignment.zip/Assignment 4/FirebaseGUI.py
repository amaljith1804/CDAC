import firebase_admin
from tkinter import *
#import firebase and tkinter library
from firebase_admin import credentials
from firebase_admin import firestore
#Insert credentials
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred)
#data base in firebase
db = firestore.client()
#create root 
root = Tk()
#title of the GUI
root.title("Upload data to firebase")
#set the size
root.geometry("500x500")
# Name the label and pack
name = Label(root,text="Enter your name",bg="light green",foreground="blue")
name.pack()
#create an entry for name upload
e = Entry(root, width=50)
#pack the name entry
e.pack()
e.insert(0,"Enter the name")
#create a label of age 
age = Label(root,text="Enter your age",bg="light green",foreground="blue")
age.pack()
#create an entry of age
f = Entry(root, width=50)
f.insert(0,"Enter Your age")
f.pack()
#create the function d with name age and employed as dictionary values
def d():
    data = {
    'name':e.get(),
    'age': f.get(),
    'employed': False,}
    #upload it to database in doc no 002
    db.collection('users').document('#002').set(data)

#create a button to call function d
myButton = Button(root, text="upload", padx=30, pady=30, command = d)
#pack the button
myButton.pack()
#exit the main loop
root.mainloop()