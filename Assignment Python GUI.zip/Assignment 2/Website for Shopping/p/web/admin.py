from django.contrib import admin
from web.models import Task
# Register your models here.
admin.site.register(Task)