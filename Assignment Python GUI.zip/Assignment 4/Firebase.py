import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

#Add doc to Firebase
data = {
    'name':"Shankar mahadevan",
    'age': 43,
    'employed': True, 
}
#To set Document with ID 
db.collection('users').document('#002').set(data)

#nested collection
db.collection('users').document('#002').collection('Movies').document('movie001').set(
    {'name':['Avatar','captain america','spiderman'],}
)
